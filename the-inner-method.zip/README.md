
# The Inner Method

This is the website for Christina's healing practice: The Inner Method.
More content coming soon.
